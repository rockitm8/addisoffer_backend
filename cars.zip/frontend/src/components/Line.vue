<template>
	<div class="line"><hr /></div>
</template>

<script>
	export default {
		name: "Line",
	};
</script>

<style scoped>
	.line {
		opacity: 0.3;
	}
</style>
