<template>
  <div class="frequently-asked-question">
    <h2>Frequently Asked Questions</h2>
    <h3 id="buyerfaq" class="mt-4">Buyer’s Questions</h3>
    <div
      class="accordion faq accordion-flush"
      id="accordionPanelsStayOpenExample"
    >
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingOne">
          <button
            class="accordion-button faq collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapseOne"
            aria-expanded="true"
            aria-controls="panelsStayOpen-collapseOne"
          >
            <b>What are the fees for the buyer on Addis Offer</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapseOne"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingOne"
        >
          <div class="accordion-body">
            The only fee a buyer pays for buying on Addis Offer is the ETB300
            (Three Hundred Birr). This payment is done at the beginning when
            they register to bid. As Addis Offer, we
            <span class="orange-txt">DONOT</span> ask for any other payment.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapseTwo"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapseTwo"
          >
            <b>How do I register to bid?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapseTwo"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingTwo"
        >
          <div class="accordion-body">
            To register to bid on Addis Offer, you can go directly to the car
            you want to bid on and click on PLACE BID, there will be a popup
            screen that give you payment detail. Using that payment detail
            information, you can make the payment and be eligible to bid.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingThree">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapseThree"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapseThree"
          >
            <b>How do bid increments work?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapseThree"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingThree"
        >
          <div class="accordion-body">
            The bid increment is all up to the bidder but our minimum bid
            increment will be ETB5000 (Five thousand Birr).
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingFour">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapseFour"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapseFour"
          >
            <b>What’s the reserve price of the car I want to buy?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapseFour"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingFour"
        >
          <div class="accordion-body">
            If a listing doesn’t have a reserve, you’ll see a “No Reserve”. If
            you don’t see this text, that auction has a reserve price. Reserve
            prices are not published, and we ask that buyers refrain from asking
            sellers about reserve pricing during the auction. The only time
            you’ll know if the reserve is met is if the car sells at auction
            close.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingfive">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapsefive"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapsefive"
          >
            <b>What if the reserve isn’t met?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapsefive"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingfive"
        >
          <div class="accordion-body">
            If you’re the high bidder on a car where the reserve isn’t met,
            we’ll work with the seller and the buyer in an attempt to find a
            sale price that’s suitable for both parties. If we’re able to reach
            an agreement, we will ask each parties for a fee of ETB5000 (Five
            Thousand Birr).
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingsix">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapsesix"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapsesix"
          >
            <b>Once the auction is over, how do I complete the transaction?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapsesix"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingsix"
        >
          <div class="accordion-body">
            At the conclusion of the auction, both the buyer and seller are
            given each other’s contact information to complete the transaction.
            Read more about Finalizing the sale.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingseven">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapseseven"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapseseven"
          >
            <b>Are there rules to follow in the comments?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapseseven"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingseven"
        >
          <div class="accordion-body">
            Yes! Aside from common-sense rules like language and personal
            attacks, the conversation should be focused on the vehicle being
            sold, so as to be fair to the seller and bidders. We want to ensure
            Addis Offer community remains an open and positive place to spend
            time with fellow members. A partial list of things that are frowned
            upon (and will be moderated accordingly) include:
            <ul>
              <li>Foul language</li>
              <li>Personal attacks</li>
              <li>Attempting to share your personal contact information</li>
              <li>Spamming</li>
              <li>Asking the seller about their reserve</li>
              <li>Calling out the price you think the vehicle will sell for</li>
              <li>Inappropriate images or descriptions in your profile</li>
              <li>
                Plugging your personal business, website, social media handles,
                etc.
              </li>
              <li>
                Sidetracking the conversation about other vehicles or topics
                unrelated to the vehicle being offered
              </li>
              <li>Linking to inappropriate videos/webpages/content</li>
              <li>Linking to other vehicle for sale ads</li>
            </ul>
          </div>
        </div>
      </div>

      <h3 id="sellerfaq">Seller Questions</h3>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingseventeen">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapseseventeen"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapseseventeen"
          >
            <b>How much does it cost to sell a car on Addis Offer?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapseseventeen"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingseventeen"
        >
          <div class="accordion-body">
            Listing a car on Addis Offer is starting from ETB500 (Five Hundred
            Birr). Given factors of coupon discounts. If coupons are used the
            price might vary depending on the coupon code.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingeighteen">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapseeighteen"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapseeighteen"
          >
            <b>How do I submit my car for sale?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapseeighteen"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingeighteen"
        >
          <div class="accordion-body">
            To submit your car for sale, go to the “Sell a Car” link in the
            header. In order to sell your car, you’ll need to provide us with
            the information – like the make, model, year, VIN, photos, and some
            other relevant details. Then we’ll ask you for a more detailed set
            of questions so we can make sure our auction description is
            accurate.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingnineteen">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapsenineteen"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapsenineteen"
          >
            <b> How do I take the best pictures of my car? </b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapsenineteen"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingnineteen"
        >
          <div class="accordion-body">
            We can’t emphasize enough how important photos are for a successful
            auction. We recommend you hire a professional photographer to come
            shoot your car.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingtwenty">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapsetwenty"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapsetwenty"
          >
            <b>Should I take a video?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapsetwenty"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingtwenty"
        >
          <div class="accordion-body">
            Yes! We’ve found that taking a video detailing the exterior
            condition, interior, engine bay, and also showing the engine start
            and run, really raises interest and increases buyer confidence. This
            can be broken up into several videos, or all in one.
            <br />
            We suggest filming in landscape mode, with the phone held
            horizontally.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingtwentyone">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapsetwentyone"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapsetwentyone"
          >
            <b>Can I schedule when my car’s auction starts?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapsetwentyone"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingtwentyone"
        >
          <div class="accordion-body">
            Although we don’t offer the ability to precisely schedule your
            auction, we allow our sellers to provide preferences. If you’d
            prefer a certain start date, or if you’d prefer if your auction
            wasn’t live during a certain week (for example, due to a vacation or
            business trip), let us know and we’ll do our best to accommodate
            you.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingtwentytwo">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapsetwentytwo"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapsetwentytwo"
          >
            <b> How long does an auction last? </b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapsetwentytwo"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingtwentytwo"
        >
          <div class="accordion-body">
            All auctions last from five to fifteen days. However, the exact
            duration can fluctuate. That’s because within the last minute of an
            auction, each new bid resets the auction clock to five minute
            remaining. This simulates a traditional auction, where bidding
            continues until bidders stop – rather than some online auctions,
            which end at a set time and favor last-second bids.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingtwentythree">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapsetwentythree"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapsetwentythree"
          >
            <b>Can I edit my auction once it’s live?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapsetwentythree"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingtwentythree"
        >
          <div class="accordion-body">
            You can’t edit your auction yourself – but throughout the duration
            of your auction, you’ll be in touch with Addis Offer. If you need to
            edit your auction, just reach out and let us know what you need to
            have changed. You can also leave comments, which include additional
            photos – and you can answer questions to help improve the clarity of
            your listing.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingtwentyfour">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapsetwentyfour"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapsetwentyfour"
          >
            <b>
              How do I respond to questions/how should I engage during the
              auction?
            </b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapsetwentyfour"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingtwentyfour"
        >
          <div class="accordion-body">
            We strongly recommend being an active participant in the comments
            section, and we ask that you respond to any questions submitted
            there, or directly from users through the Contact Seller option.
            Sellers who participate actively are the most successful. As always,
            staying positive and constructive with your answers will only
            increase confidence from potential bidders.
            <br />
            Keep in mind that the buyer is a car enthusiast just like you, and
            they likely wouldn’t be asking unless they’re seriously interested
            in your car!
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingtwentyfive">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapsetwentyfive"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapsetwentyfive"
          >
            <b>Can I put a reserve price on my auction?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapsetwentyfive"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingtwentyfive"
        >
          <div class="accordion-body">
            Yes, we offer sellers the choice between a “reserve” and a “no
            reserve” auction. A “reserve” is a minimum price that a seller is
            willing to accept for a car, which is unknown to buyers during the
            auction. A “no reserve” auction has no minimum price, meaning the
            car will sell for the amount of the high bid.
            <br />
            If you choose a reserve auction, we will ask you to suggest a
            reserve price – but we may ask for a lower one before we’re willing
            to list the car for sale. If we can’t agree on a reserve price, no
            hard feelings – of course, you’re free to sell the car elsewhere.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingtwentysix">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapsetwentysix"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapsetwentysix"
          >
            <b>Should I disclose my reserve price?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapsetwentysix"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingtwentysix"
        >
          <div class="accordion-body">
            We recommend never revealing your reserve, especially in the public
            comments sections. We’ve found that disclosing a reserve price
            almost always slows down bidding, especially as the auction nears or
            reaches that value.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingtwentyseven">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapsetwentyseven"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapsetwentyseven"
          >
            <b>Can I try to make a deal outside of the auction?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapsetwentyseven"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingtwentyseven"
        >
          <div class="accordion-body">
            No – vehicles listed on Addis Offer are for sale exclusively through
            the auction. If a buyer or seller attempts to make a deal in an
            attempt to subvert the auction, we will permanently ban you from the
            site. Instead, if you want to buy a car on Addis Offer, simply bid
            the maximum you’re willing to pay – it’s the best way to ensure
            you’ll end up with the car you want.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingtwentyeight">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapsetwentyeight"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapsetwentyeight"
          >
            <b>What if my reserve isn’t met?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapsetwentyeight"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingtwentyeight"
        >
          <div class="accordion-body">
            If your reserve isn’t met, we’ll get in touch with you and with the
            highest bidder on your auction, and we’ll try to negotiate a price
            that will satisfy both parties. If we reach an agreement, we will
            ask each parties for a fee of ETB5000 (Five Thousand Birr).
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingtwentynine">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapsetwentynine"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapsetwentynine"
          >
            <b> How does the buyer get in contact with me and make payment? </b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapsetwentynine"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingtwentynine"
        >
          <div class="accordion-body">
            Once the auction is over, completion of the transaction is between
            the buyer and the seller. Addis Offer provides the buyer and seller
            with each other’s contact information, and the two parties can
            complete the transaction. Read more about Finalizing the sale.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingthirty">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapsethirty"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapsethirty"
          >
            <b>How long do you keep past auctions available for review?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapsethirty"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingthirty"
        >
          <div class="accordion-body">
            we keep all auctions perpetually available for all to see regardless
            of their outcome. We do this because we feel it’s essential to be
            transparent in order to build trust within the enthusiast community.
          </div>
        </div>
      </div>

      <h3 id="signinfaq">Sign in Questions</h3>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingfourty">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapsefourty"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapsefourty"
          >
            <b>How can I sign in?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapsefourty"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingfourty"
        >
          <div class="accordion-body">
            You can sign in using an email address and password.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingfourtyone">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapsefourtyone"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapsefourtyone"
          >
            <b>Why do you need my email address?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapsefourtyone"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingfourtyone"
        >
          <div class="accordion-body">
            All users need to provide an email address. This is the address
            where you’ll receive saved search notifications, communication from
            our team about your auctions or bids, and the address that is shared
            with the other party when you win an auction or sell your car.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-headingfourtytwo">
          <button
            class="accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#panelsStayOpen-collapsefourtytwo"
            aria-expanded="false"
            aria-controls="panelsStayOpen-collapsefourtytwo"
          >
            <b>What do I do if I forgot my password?</b>
          </button>
        </h2>
        <div
          id="panelsStayOpen-collapsefourtytwo"
          class="accordion-collapse collapse"
          aria-labelledby="panelsStayOpen-headingfourtytwo"
        >
          <div class="accordion-body">
            Click the “Sign In” button at the top right of your screen. If you
            see the Sign Up screen, click the “Sign in here” link to go to Sign
            In. At the bottom of the screen click the “Forgot your password?”
            link. Enter the email address of your account, and we will email you
            a link to set a new password.
            <br />
            Make sure you have access to the email account, as this link expires
            in a short period of time.
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'Faq',
  };
</script>

<style scoped>
  button {
    padding-left: 0px;
  }

  .frequently-asked-question .line {
    margin-top: 40px;
    opacity: 0.3;
  }
  .frequently-asked-question h1 {
    font-size: 36px;
    margin-top: 50px;
  }
  .frequently-asked-question h3 {
    margin-top: 40px;
  }

  .frequently-asked-question b {
    font-weight: 500;
  }

  .frequently-asked-question p {
    margin-bottom: 50px;
  }

  .frequently-asked-question ul li {
    margin-bottom: 10px;
    line-height: 35px;
    font-size: 18px;
  }

  .register {
    color: var(--main-color);
    text-decoration: none;
  }

  .register:hover {
    color: black;
    transition: 0.3s;
    text-decoration: underline;
  }

  .orange-txt {
    color: var(--main-color);
  }

  @media only screen and (max-width: 991px) {
    .frequently-asked-question p {
      font-size: 16px;
    }
    .frequently-asked-question h1 {
      font-size: 28px;
    }
    .frequently-asked-question ul li {
      font-size: 16px;
    }

    .register a {
      color: var(--main-color);
    }
  }
  .faq.collapsed {
    background: #ffff;
  }

  .accordian-button.faq {
    background: #ffff;
    color: white;
  }

  .accordion-button:focus {
    box-shadow: 0 0 0 0.1rem #ffc681;
  }

  .accordion-button:not(.collapsed) {
    color: black;
    background-color: white;
    background-image: black;
  }

  .accordion-button:not(.collapsed)::after {
    background-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='black'><path fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/></svg>");
  }

  .last-text p {
    margin-top: 90px;
    font-size: 14px !important;
    color: rgb(130, 130, 130);
  }

  a:hover {
    color: #834f0f;
    text-decoration: underline;
  }
</style>
