<template>
  <div class="about-main">
    <h1 class="heading-border">What's Addis Offer?</h1>
    <div class="row">
      <img class="icons-img" src="../../assets/icons.png" alt="" />
      <div class="initial-para">
        <p>
          <span class="head-para">Lowest fees:</span> Unlike any other market in
          the industry, we offer the
          <span class="orange-txt">lowest price</span>.
        </p>
        <p>
          <span class="head-para">Community:</span>
          <span class="orange-txt"> Reach</span> all the car markets in one
          place.
        </p>
        <p>
          <span class="head-para">Transparency:</span> All our auctions are
          <span class="orange-txt">real-time prices</span>.
        </p>
        <p>
          <span class="head-para">Time-saving:</span> Sell your car
          <span class="orange-txt">faster</span> than ever before.
        </p>
        <p>
          <span class="head-para">Easy to use:</span> With just a
          <span class="orange-txt">few clicks</span> you are on your way to
          selling and buying your car.
        </p>
        <p>
          <span class="head-para">Impartiality:</span> Let the
          <span class="orange-txt">market</span> decide the price for you, not
          the brokers.
        </p>
      </div>

      <Line />
    </div>
    <div id="aboutus" class="sec-3">
      <h2 class="mb-5">About Us</h2>
      <p>
        Lately, the Ethiopian car market has changed dramatically. The demand
        for cars and the suppliers (Sellers) has always followed the single and
        same way of trading.
      </p>
      <p>
        Our company, Addis Offer, offers the most common and easiest way of
        buying and selling: auctioning.
      </p>
      <p>
        We have created this system to enable buyers to buy the cars of their
        choice by the valuation they create for it as well as the interest they
        have for that particular car. The sellers will be able to sell their
        cars quicker than the traditional way as well as get more value for
        them.
      </p>
      <Line />
    </div>

    <div id="buying" class="sec-4 mt-5">
      <h2>How It Works</h2>
      <h3 class="mt-5">Buying a Car</h3>

      <h5 class="mt-5 mb-3">1. Register to Bid</h5>
      <p>
        To be a valid buyer on our platform, you must complete the necessary
        payment.
      </p>

      <div>
        <h5 class="mt-5 mb-3">2. Perform your due diligence</h5>
        <p>
          Even though we make the process of buying and selling cars easy, we
          highly recommend buyers do their due diligence thoroughly before they
          place bids. This is fully the buyer's responsibility; we will not be
          asked for it.
        </p>
        <p>Review the car deeply.</p>
        <p>Ask the seller for any information you may need</p>
        <p>
          If necessary, ask the seller to see the car in person and get an
          inspection specialist or a mechanic.
        </p>
      </div>
      <div>
        <h5>3. Bid</h5>
        <p>
          Now you are one step away from buying a car, put your price for the
          car, and the amount you are willing to pay for it.
        </p>
        <p>
          Bids are binding so only bid to buy because you might end up being the
          highest bidder.
        </p>
        <p>
          To ensure the bidding process is fair, bids placed within the final
          minute of the auction will reset the auction’s time remaining back to
          5 minutes allowing others to bid.
        </p>
      </div>

      <div>
        <h5>4. Win</h5>
        <p>
          The only way to win on Addis Offer is by being the highest bidder.
          This is done in two ways
        </p>
        <ul>
          <li>
            If the auction has a <span class="orange-txt">reserve price</span>,
            by placing a bid that meets or exceeds the seller’s hidden reserve
            price.
          </li>
          <li>
            If the auction is a
            <span class="orange-txt">NO RESERVE PRICE</span>, the highest bidder
            will be the winner of the auction regardless of the amount you bid.
          </li>
        </ul>
      </div>
      <div id="selling">
        <h3>Sell your car</h3>
        <p>When selling your car on our platform:</p>
        <h5>1. Submit your car information</h5>
        <p>
          Using the form, we have provided give us a piece of detailed
          information about your car. You have to decide whether you want a
          reserve price or not. Keep in mind that all of our auctions start from
          ETB 0, regardless of whether or not they have a reserve.
        </p>
        <h5>2. We will review your form</h5>
        <p>
          All the information you provided to us will be reviewed by our team
          and we will proceed to the payment.
        </p>
        <p>
          We will be providing you with a payment option and bank account as
          well. We require a screenshot or a photo of the bank receipt sent to
          our Facebook, Telegram, or WhatsApp addresses.
        </p>
        <p>
          The price of selling a car is starting from ETB500 (Five Hundred
          Birr).
        </p>
      </div>
      <div>
        <h5>3. Create an outstanding listing</h5>
        <p>
          We will contact you to create the best listing that can outstand from
          the others. We will discuss your preference and try to get great shots
          that can stand out.
        </p>
        <p>
          We will also discuss the time of listing, that would best fit your
          preference.
        </p>
      </div>
      <div>
        <h5>4. Participate in the Auction</h5>
        <p>
          Once we list your car on our platform, we will ask you to stay active
          in the auction. This is to:
        </p>
        <ul>
          <li>
            You will need to reply to comments and answer questions actively.
          </li>
          <li>
            Buyers may want to contact you; you have to be able to set up a
            meeting if necessary and up to your convenience.
          </li>
        </ul>
      </div>
      <div>
        <h5>5. Auction End</h5>
        <p>
          After the completion of the auction, we will notify both parties to
          finalize the deal. We can assist if necessary.
        </p>
        <p>
          If the auction had a reserve price and was not met, we will try to
          negotiate a deal with the highest bidder to help make a deal.
        </p>
      </div>
      <div id="sale">
        <h3>Finalizing the Sale</h3>
        <p>
          Once the auction ends and a car is sold, we will connect the buyer and
          seller to complete the sale directly.
        </p>
        <p>
          All the documentation and necessary things are supposed to be provided
          by both parties at the time of the meeting.
        </p>
        <p>
          The agreement that is going to hold after the two parties met is all
          up to the parties themselves. Addis Offer is not going to be held
          liable for any agreements held after the auction.
        </p>
        <p>
          If the seller has a debt to pay off, they should do so before the
          auction is complete and provide a clean title paper or so discuss how
          to close the loan with the seller, and arrange a means of an agreement
          to close the loan and pay off the remaining to the seller.
        </p>
        <p>
          The transaction should be done through a bank and a payment receipt
          should be kept on hand by the buyer at all times along with a letter
          from the bank indicating that the two parties have made a transaction
          for the amount they bid and sold.
        </p>
      </div>
      <Line />
    </div>
  </div>
</template>

<script>
  import Line from '../Line.vue';
  export default {
    name: 'AboutMain',
    components: { Line },
  };
</script>

<style scoped>
  .icons-img {
    width: 40%;
    margin-top: 70px;
    margin-left: 20%;
    position: relative;
  }

  .initial-para {
    margin-top: 80px;
  }

  .head-para {
    font-weight: 600;
  }

  .orange-txt {
    color: var(--main-color);
    font-weight: 700;
  }

  .sec-2 h1 {
    font-weight: 700;
    line-height: 60px;
    display: inline-block;
    position: relative;
  }

  .sec-2 .heading-border {
    border-bottom: 10px solid #ffe55f;
    border-radius: 3px;
  }

  .sec-2 .small-images {
    width: 48px;
    height: 48px;
    display: block;
    margin-bottom: 20px;
    margin-top: 30px;
  }

  .sec-2 h3 {
    margin-bottom: 22px;
    font-weight: 700;
    font-size: 22px;
    line-height: 20px;
  }

  .sec-2 p {
    font-size: 18px;
    line-height: 26px;
    display: block;
  }

  .sec-2 .line {
    margin-top: 40px;
    opacity: 0.3;
  }
  .sec-3 h2 {
    font-size: 36px;
    margin-top: 50px;
    font-weight: 700;
  }

  .sec-3 p {
    margin-bottom: 50px;
  }

  .sec-3 ul li {
    line-height: 40px;
    font-size: 18px;
  }
  .register {
    color: var(--main-color);
    text-decoration: none;
  }
  .register :hover {
    color: black;
    transition: 0.3s;
  }

  @media only screen and (max-width: 991px) {
    .sec-3 p {
      font-size: 16px;
    }
    .sec-3 h1 {
      font-size: 28px;
    }
    .sec-3 ul li {
      font-size: 16px;
    }
  }
  .sec-4 .line {
    margin-top: 40px;
    opacity: 0.3;
  }
  .sec-4 h2 {
    font-size: 36px;
    margin-top: 50px;
    font-weight: 700;
  }

  .sec-4 p {
    margin-bottom: 50px;
  }

  .sec-4 ul li {
    margin-bottom: 10px;
    line-height: 35px;
    font-size: 18px;
  }

  .register {
    color: var(--main-color);
    text-decoration: none;
  }

  .register :hover {
    color: black;
    transition: 0.3s;
  }

  a:hover {
    color: #834f0f;
    text-decoration: underline;
  }

  @media only screen and (max-width: 991px) {
    .sec-4 p {
      font-size: 16px;
    }
    .sec-4 h1 {
      font-size: 28px;
    }
    .sec-4 ul li {
      font-size: 16px;
    }

    .register a {
      color: var(--main-color);
    }
  }
</style>
