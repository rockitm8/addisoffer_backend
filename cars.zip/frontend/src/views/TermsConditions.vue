<template>
  <div class="terms-conditions">
    <h1>Terms of Use</h1>
    <p>
      Welcome to Addis Offer Please read on to learn the rules and restrictions
      that govern your use of our website(s), products, services and
      applications (the “Services”). If you have any questions, comments, or
      concerns regarding these terms or the Services, please contact us at:
    </p>
    <p>Email: contact@addisoffer.com</p>
    <p>Phone: +251910932337</p>
    <p>Address: Gerji Mebrat Hail, Addis Ababa Ethiopia</p>
    <p>
      These Terms of Use (the “Terms”) are a binding contract between you and
      Addis Offer (“Addis Offer,” “we” and “us”). Your use of the Services in
      any way means that you agree to all of these Terms, and these Terms will
      remain in effect while you use the Services. These Terms include the
      provisions in this document as well as those in the Privacy Policy.
    </p>
    <p>
      <b>Please read these Terms carefully.</b> They cover important information
      about Services provided to you.
      <b
        >These Terms include information about future changes to these Terms,
        limitations of liability, a class action waiver and resolution of
        disputes by arbitration instead of in court. PLEASE NOTE THAT YOUR USE
        OF AND ACCESS TO OUR SERVICES ARE SUBJECT TO THE FOLLOWING TERMS; IF YOU
        DO NOT AGREE TO ALL OF THE FOLLOWING, YOU MAY NOT USE OR ACCESS THE
        SERVICES IN ANY MANNER.</b
      >
    </p>
    <p>
      <b>ARBITRATION NOTICE AND CLASS ACTION WAIVER:</b> EXCEPT FOR CERTAIN
      TYPES OF DISPUTES DESCRIBED IN THE ARBITRATION AGREEMENT SECTION BELOW,
      YOU AGREE THAT DISPUTES BETWEEN YOU AND US WILL BE RESOLVED BY BINDING,
      INDIVIDUAL ARBITRATION AND YOU WAIVE YOUR RIGHT TO PARTICIPATE IN A CLASS
      ACTION LAWSUIT OR CLASS-WIDE ARBITRATION.
    </p>
    <h2>Connecting Car Sellers and Bidders</h2>
    <p>
      Addis Offer connects those offering cars for sale (“Sellers”) and those
      looking to acquire cars (“Bidders”). The Services act as a meeting place
      only; the actual contract for sale for each car listed on the Services is
      directly between the Seller and the winning Bidder.
    </p>
    <p>
      When we use the word “you” in these Terms, it refers to any user,
      regardless of whether he or she is a Seller, Bidder, other registered user
      or unregistered user, while if we use one of those specific terms, it only
      applies to that category of user.
    </p>
    <p>
      Before acquiring a car from any Seller (each, a “Seller Car”), Bidders are
      responsible for making their own determinations that the Seller Car is
      suitable. Addis Offer is only responsible for connecting Sellers and
      Bidders, and can’t and won’t be responsible for making sure that any
      Seller Car is up to a certain standard of quality. Addis Offer similarly
      can’t and won’t be responsible for ensuring that information (including
      credentials) any Bidder or Seller provides about himself or herself or
      about any Seller Car he or she is offering is accurate or up-to-date. Each
      Seller acknowledges and agrees that they shall make reasonable efforts to
      complete the sale of their Seller Car if there is a winning bid. Each
      Bidder acknowledges and agrees that if they are the winning bidder in an
      auction through the Services, their bid is binding on the Bidder and
      Bidder is responsible for all applicable government fees and taxes for the
      vehicle won through such bid. Notwithstanding the foregoing, we don’t
      control the actions of any Bidder or Seller, and Sellers aren’t our
      employees.
    </p>
    <p>
      <b
        >ADDIS OFFER DOES NOT DIRECTLY OFFER THE SELLER CARS. YOU HEREBY
        ACKNOWLEDGE THAT ADDIS OFFER DOES NOT SUPERVISE, DIRECT, CONTROL OR
        MONITOR THE SELLER CARS AND EXPRESSLY DISCLAIMS ANY RESPONSIBILITY AND
        LIABILITY FOR THE SELLER CARS, INCLUDING BUT NOT LIMITED TO ANY WARRANTY
        OR CONDITION OF QUALITY OR FITNESS FOR A PARTICULAR PURPOSE, OR
        COMPLIANCE WITH ANY LAW, REGULATION, OR CODE.</b
      >
    </p>
    <p>
      Sellers may not remove a car made available for auction on the Services
      before the end of such auction. While a Seller Car is listed on the
      Services, Seller may not list or make available such Seller Car on any
      other auction, dealership, listing service or publication.
    </p>
    <h2>Will these Terms ever change?</h2>
    <p>
      We are constantly trying to improve our Services, so these Terms may need
      to change along with our Services. We reserve the right to change the
      Terms at any time, but if we do, we will place a notice on our site, send
      you an email, and/or notify you by some other means.
    </p>
    <p>
      If you don’t agree with the new Terms, you are free to reject them;
      unfortunately, that means you will no longer be able to use the Services.
      If you use the Services in any way after a change to the Terms is
      effective, that means you agree to all of the changes.
    </p>
    <p>
      Except for changes by us as described here, no other amendment or
      modification of these Terms will be effective unless in writing and signed
      by both you and us.
    </p>

    <h2>What about my privacy?</h2>
    <p>
      Addis Offer takes the privacy of its users very seriously. For the current
      Addis Offer Privacy Policy, please click here.
    </p>
    <h2>What are the basics of using Addis Offer?</h2>
    <p>
      You may be required to sign up for an account, select a password and user
      name (“Addis Offer User ID”), and provide us with certain information or
      data, such as your contact information. You promise to provide us with
      accurate, complete, and updated registration information about yourself.
      You may not select as your Addis Offer User ID a name that you do not have
      the right to use, or another person’s name with the intent to impersonate
      that person. You may not transfer your account to anyone else without our
      prior written permission.
    </p>
    <p>
      You represent and warrant that you are an individual of legal age to form
      a binding contract (or if not, you’ve received your parent’s or guardian’s
      permission to use the Services and have gotten your parent or guardian to
      agree to these Terms on your behalf). If you’re agreeing to these Terms on
      behalf of an organization or entity, you represent and warrant that you
      are authorized to agree to these Terms on that organization’s or entity’s
      behalf and bind them to these Terms (in which case, the references to
      “you” and “your” in these Terms, except for in this sentence, refer to
      that organization or entity).
    </p>
    <p>
      You will only use the Services for your own internal, personal use, and
      not on behalf of or for the benefit of any third party. You will comply
      with all laws that apply to you, your use of the Services, and your
      actions and omissions that relate to the Services (for example, Sellers
      must comply with all laws that relate to the Seller Cars). If your use of
      the Services is prohibited by applicable laws, then you aren’t authorized
      to use the Services. We can’t and won’t be responsible for your using the
      Services in a way that breaks the law.
    </p>
    <p>
      You will not share your Addis Offer User ID, account or password with
      anyone, and you must protect the security of your Addis Offer User ID,
      account, password and any other access tools or credentials. You’re
      responsible for any activity associated with your Addis Offer User ID and
      account.
    </p>
    <h2>What about messaging?</h2>
    <p>
      As part of the Services, you may receive communications through the
      Services, including messages that Addis Offer sends you (for example, via
      email). When signing up for the Services, you will receive a welcome
      message and instructions on how to stop receiving certain marketing
      messages.
    </p>
    <h2>Are there restrictions in how I can use the Services?</h2>
    <p>
      You represent, warrant, and agree that you will not contribute any Content
      or User Submission (each of those terms is defined below) or otherwise use
      the Services or interact with the Services in a manner that:
    </p>
    <ul>
      <li>
        infringes or violates the intellectual property rights or any other
        rights of anyone else (including Addis Offer);
      </li>
      <li>
        violates any law or regulation, including, without limitation, any
        applicable export control laws, privacy laws or any other purpose not
        reasonably intended by Addis Offer;
      </li>
      <li>
        is dangerous, harmful, fraudulent, deceptive, threatening, harassing,
        defamatory, obscene, or otherwise objectionable (including, without
        limitation, by creating multiple accounts for purposes of cheating or
        gaming the bidding system);
      </li>
      <li>
        jeopardizes the security of your Addis Offer User ID, account or anyone
        else’s (such as allowing someone else to log in to the Services as you);
      </li>
      <li>
        attempts, in any manner, to obtain the password, account, or other
        security information from any other user;
      </li>
      <li>
        violates the security of any computer network, or cracks any passwords
        or security encryption codes;
      </li>
      <li>
        runs Maillist, Listserv, any form of auto-responder or “spam” on the
        Services, or any processes that run or are activated while you are not
        logged into the Services, or that otherwise interfere with the proper
        working of the Services (including by placing an unreasonable load on
        the Services’ infrastructure);
      </li>
      <li>
        “crawls,” “scrapes,” or “spiders” any page, data, or portion of or
        relating to the Services or Content (through use of manual or automated
        means);
      </li>
      <li>copies or stores any significant portion of the Content; or</li>
      <li>
        decompiles, reverse engineers, or otherwise attempts to obtain the
        source code or underlying ideas or information of or relating to the
        Services.
      </li>
    </ul>
    <p>
      A violation of any of the foregoing is grounds for termination of your
      right to use or access the Services as well as lead to court.
    </p>
    <h2>How may I use information obtained from other users?</h2>
    <p>
      You may not collect any information from or relating to another user
      (“User Information”), whether via the Services, in the course of offering
      or making an offer on Seller Cars, as applicable, or otherwise, beyond
      what is necessary to complete your diligence and the auction transaction.
      Upon the conclusion of an auction, you must properly destroy all User
      Information from or relating to such user and make no further use of it
      whatsoever. You must collect, use, maintain, and transmit all User
      Information in compliance with all applicable laws.
    </p>
    <h2>What are my rights in the Services?</h2>
    <p>
      The materials displayed or performed or available on or through the
      Services, including, but not limited to, text, graphics, data, articles,
      photos, images, illustrations, User Submissions (as defined below) and so
      forth (all of the foregoing, the “Content”) are protected by copyright
      and/or other intellectual property laws. You promise to abide by all
      copyright notices, trademark rules, information, and restrictions
      contained in any Content you access through the Services, and you won’t
      use, copy, reproduce, modify, translate, publish, broadcast, transmit,
      distribute, perform, upload, display, license, sell, commercialize or
      otherwise exploit for any purpose any Content not owned by you, (i)
      without the prior consent of the owner of that Content or (ii) in a way
      that violates someone else’s (including Addis Offers’) rights.
    </p>
    <p>
      Subject to these Terms, we grant each user of the Services a worldwide,
      non-exclusive, non-sublicensable and non-transferable license to use
      (i.e., to download and display locally) Content solely for purposes of
      using the Services. Use, reproduction, modification, distribution or
      storage of any Content for any purpose other than using the Services is
      expressly prohibited without prior written permission from us. You
      understand that Addis Offer owns the Services. You won’t modify, publish,
      transmit, participate in the transfer or sale of, reproduce (except as
      expressly provided in this Section), create derivative works based on, or
      otherwise exploit any of the Services. The Services may allow you to copy
      or download certain Content, but please remember that even where these
      functionalities exist, all the restrictions in this section still apply.
    </p>
    <h2>
      What about anything I contribute to the Services – do I have to grant any
      licenses to Addis Offer or to other users?
    </h2>
    <h3>User Submissions</h3>
    <p>
      Anything you post, upload, share, store, or otherwise provide through the
      Services is your “User Submission”. Some User Submissions may be viewable
      by other users. You are solely responsible for all User Submissions you
      contribute to the Services. You represent that all User Submissions
      submitted by you are accurate, complete, up-to-date, and in compliance
      with all applicable laws, rules and regulations.
    </p>
    <p>
      You agree that you will not post, upload, share, store, or otherwise
      provide through the Services any User Submissions that: (i) infringe any
      third party’s copyrights or other rights (e.g., trademark, privacy rights,
      etc.); (ii) contain sexually explicit content or pornography; (iii)
      contain hateful, defamatory, or discriminatory content or incite hatred
      against any individual or group; (iv) exploit minors; (v) depict unlawful
      acts or extreme violence; (vi) depict animal cruelty or extreme violence
      towards animals; (vii) promote fraudulent schemes, multi-level marketing
      (MLM) schemes, get rich quick schemes, online gaming and gambling, cash
      gifting, work from home businesses, or any other dubious money-making
      ventures; or (viii) violate any law.
    </p>
    <h3>Licenses</h3>
    <p>
      In order to display your User Submissions on the Services, and to allow
      other users to enjoy them (where applicable), you grant us the rights in
      those User Submissions (see below for more information). Please note that
      all of the following licenses are subject to our Privacy Policy to the
      extent they relate to User Submissions that are also your
      personally-identifiable information.
    </p>
    <p>
      By submitting User Submissions through the Services, you hereby do and
      shall grant Addis Offer a worldwide, non-exclusive, perpetual,
      royalty-free, fully paid, sublicensable and transferable license to use,
      edit, modify, truncate, aggregate, reproduce, distribute, prepare
      derivative works of, display, perform, and otherwise fully exploit the
      User Submissions in connection with this site, the Services and our (and
      our successors’ and assigns’) businesses, including without limitation for
      promoting and redistributing part or all of this site or the Services (and
      derivative works thereof) in any media formats and through any media
      channels (including, without limitation, third party websites and feeds),
      and including after your termination of your account or the Services. You
      also hereby do and shall grant each user of this site and/or the Services
      a non-exclusive, perpetual license to access your User Submissions through
      this site and/or the Services, and to use, edit, modify, reproduce,
      distribute, prepare derivative works of, display and perform such User
      Submissions, including after your termination of your account or the
      Services. For clarity, the foregoing license grants to us and our users do
      not affect your other ownership or license rights in your User
      Submissions, including the right to grant additional licenses to your User
      Submissions, unless otherwise agreed in writing. You represent and warrant
      that you have all rights to grant such licenses to us without infringement
      or violation of any third party rights, including without limitation, any
      privacy rights, publicity rights, copyrights, trademarks, contract rights,
      or any other intellectual property or proprietary rights.
    </p>
    <p>
      Finally, you understand and agree that Addis Offer, in performing the
      required technical steps to provide the Services to our users (including
      you), may need to make changes to your User Submissions to conform and
      adapt those User Submissions to the technical requirements of connection
      networks, devices, services, or media, and the foregoing licenses include
      the rights to do so.
    </p>
    <h2>
      What if I see something on the Services that infringes my copyright?
    </h2>
    <p>
      We’ve adopted the following policy toward copyright infringement. We
      reserve the right to (1) block access to or remove material that we
      believe in good faith to be copyrighted material that has been illegally
      copied and distributed by any of our advertisers, affiliates, content
      providers, members or users and (2) remove and discontinue service to
      repeat offenders.
    </p>
    <ul>
      <li>
        Procedure for Reporting Copyright Infringements. If you believe that
        material or content residing on or accessible through the Services
        infringes your copyright (or the copyright of someone whom you are
        authorized to act on behalf of), please send a notice of copyright
        infringement containing the following information to Addis Offers’
        Designated Agent to Receive Notification of Claimed Infringement (our
        “Designated Agent,” whose contact details are listed below):
        <ul>
          <li>
            A physical or electronic signature of a person authorized to act on
            behalf of the owner of the copyright that has been allegedly
            infringed;
          </li>
          <li>Identification of works or materials being infringed;</li>
          <li>
            Identification of the material that is claimed to be infringing
            including information regarding the location of the infringing
            materials that the copyright owner seeks to have removed, with
            sufficient detail so that Company is capable of finding and
            verifying its existence;
          </li>
          <li>
            Contact information about the notifier including address, telephone
            number and, if available, email address;
          </li>
          <li>
            A statement that the notifier has a good faith belief that the
            material identified in (1)(c) is not authorized by the copyright
            owner, its agent, or the law; and
          </li>
          <li>
            A statement made under penalty of perjury that the information
            provided is accurate and the notifying party is authorized to make
            the complaint on behalf of the copyright owner.
          </li>
        </ul>
      </li>
      <li>
        Once Proper Infringement Notification is Received by the Designated
        Agent. Upon receipt of a proper notice of copyright infringement, we
        reserve the right to:
        <ul>
          <li>remove or disable access to the infringing material;</li>
          <li>
            notify the content provider who is accused of infringement that we
            have removed or disabled access to the applicable material; and
          </li>
          <li>
            terminate such content provider's access to the Services if he or
            she is a repeat offender.
          </li>
        </ul>
      </li>
      <li>
        Procedure to Supply a Counter-Notice to the Designated Agent. If the
        content provider believes that the material that was removed (or to
        which access was disabled) is not infringing, or the content provider
        believes that it has the right to post and use such material from the
        copyright owner, the copyright owner's agent, or, pursuant to the law,
        the content provider may send us a counter-notice containing the
        following information to the Designated Agent:
        <ul>
          <li>A physical or electronic signature of the content provider;</li>
          <li>
            Identification of the material that has been removed or to which
            access has been disabled and the location at which the material
            appeared before it was removed or disabled;
          </li>
          <li>
            A statement that the content provider has a good faith belief that
            the material was removed or disabled as a result of mistake or
            misidentification of the material; and
          </li>
          <li>
            Content provider's name, address, telephone number, and, if
            available, email address, and a statement that such person or entity
            consents to the jurisdiction of the Federal Court for the judicial
            district in which the content provider’s address is located.
          </li>
        </ul>
      </li>
    </ul>
    <p>
      If a counter-notice is received by the Designated Agent, Company may, in
      its discretion, send a copy of the counter-notice to the original
      complaining party informing that person that Company may replace the
      removed material or cease disabling it in 10 business days. Unless the
      copyright owner files an action seeking a court order against the content
      provider accused of committing infringement, the removed material may be
      replaced or access to it restored in 10 to 14 business days or more after
      receipt of the counter-notice, at Company's discretion.
    </p>
    <p>
      Please contact Addis Offers’ Designated Agent at the following address:
    </p>
    <ul>
      <li>Addis Offer</li>
      <li>Contact@addisoffer.com</li>
      <li>+251910932337</li>
      <li>Gerji Mebrat Hail, Addis Ababa Ethiopia</li>
    </ul>
    <h2>Who is responsible for what I see and do on the Services?</h2>
    <p>
      Any information or Content publicly posted or privately transmitted
      through the Services is the sole responsibility of the person from whom
      such Content originated, and you access all such information and Content
      at your own risk, and we aren’t liable for any errors or omissions in that
      information or Content or for any damages or loss you might suffer in
      connection with it. We cannot control and have no duty to take any action
      regarding how you may interpret and use the Content or what actions you
      may take as a result of having been exposed to the Content, and you hereby
      release us from all liability for you having acquired or not acquired
      Content through the Services. We can’t guarantee the identity of any users
      with whom you interact in using the Services and are not responsible for
      which users gain access to the Services.
    </p>
    <p>
      You are responsible for all Content you contribute, in any manner, to the
      Services, and you represent and warrant you have all rights necessary to
      do so, in the manner in which you contribute it.
    </p>
    <p>
      The Services may contain links or connections to third-party websites or
      services that are not owned or controlled by Addis Offer. When you access
      third-party websites or use third-party services, you accept that there
      are risks in doing so, and that Addis Offer is not responsible for such
      risks.
    </p>
    <p>
      Addis Offer has no control over, and assumes no responsibility for, the
      content, accuracy, privacy policies, or practices of or opinions expressed
      in any third-party websites or by any third party that you interact with
      through the Services. In addition, Addis Offer will not and cannot
      monitor, verify, censor or edit the content of any third-party site or
      service. We encourage you to be aware when you leave the Services and to
      read the terms and conditions and privacy policy of each third-party
      website or service that you visit or utilize. By using the Services, you
      release and hold us harmless from any and all liability arising from your
      use of any third-party website or service.
    </p>
    <p>
      If there is a dispute between participants on this site or Services, or
      between users and any third party, you agree that Addis Offer is under no
      obligation to become involved. In the event that you have a dispute with
      one or more other users, you release Addis Offer, its directors, officers,
      employees, agents, and successors from claims, demands, and damages of
      every kind or nature, known or unknown, suspected or unsuspected,
      disclosed or undisclosed, arising out of or in any way related to such
      disputes and/or our Services.
    </p>
    <h2>Will Addis Offer ever change the Services?</h2>
    <p>
      We’re always trying to improve our Services, so wemay change over time. We
      may suspend or discontinue any part of the Services, or we may introduce
      new features or impose limits on certain features or restrict access to
      parts or all of the Services. We reserve the right to remove any Content
      from the Services at any time, for any reason (including, but not limited
      to, if someone alleges you contributed that Content in violation of these
      Terms), in our sole discretion, and without notice.
    </p>
    <h2>Do the Services cost anything?</h2>
    <p>
      It is free to register for the Services but certain aspects of the
      Services may require that you pay us fees. If you decide to use these paid
      aspects of the Services, you agree to the Fees Terms set forth below, as
      we may amend them from time to time.
    </p>
    <p>
      We reserve the right to charge for certain or all Services in the future.
      We will notify you before any Services you are then using begin carrying a
      fee, and if you wish to continue using such Services, you must pay all
      applicable fees for such Services.
    </p>
    <p>
      You must pay all fees and applicable taxes associated with our Services by
      the payment due date.
    </p>
    <h2>Fees</h2>
    <h3>Listing Fees</h3>
    <p>
      The current fee ranges from ETB500-20,000 (Five Hundred to twenty thousand
      Birr) to list a Car on the Services.
    </p>
    <h3>Bidders’ Fees</h3>
    <p>
      We require bidders’ a fee of ETB300 (Three Hundred Birr) to be eligible to
      bid on a car. This price only applies to a single bidding. Users can bid
      on up to 10 cars at a given time period.
    </p>
    <p>
      Please visit our “What is Addis Offer” and “Sell a car” pages for more
      information about our reserve sales and other product features.
    </p>
    <h2>What if I want to stop using the Services?</h2>
    <p>
      You’re free to do that at any time by contacting us at
      contact@addisoffer.com.
    </p>
    <p>
      Addis Offer is also free to terminate (or suspend access to) your use of
      the Services or your account for any reason in our discretion, including
      your breach of these Terms. Addis Offer has the sole right to decide
      whether you are in violation of any of the restrictions set forth in these
      Terms; for example, a Bidder who believes that a Seller may be in breach
      of these Terms is not able to enforce these Terms against that Seller.
    </p>
    <p>
      Account termination may result in destruction of any Content associated
      with your account, so keep that in mind before you decide to terminate
      your account.
    </p>
    <p>
      If you have deleted your account by mistake, contact us immediately at
      contact@addisoffer.com – we will try to help, but unfortunately, we can’t
      promise that we can recover or restore anything.
    </p>
    <p>
      <b
        >Please Contact us for the Amharic version of this Terms of use
        documentation.</b
      >
    </p>
  </div>
</template>

<script>
  export default {
    name: 'TermsConditions',
  };
</script>

<style scoped>
  .terms-conditions {
    padding-top: 50px;
    padding-bottom: 50px;
  }

  h1 {
    font-size: 35px;
    font-weight: 700;
  }

  h2 {
    font-size: 25px;
    font-weight: 600;
    text-decoration: underline;
  }

  h3 {
    font-size: 15px;
    text-decoration: underline;
  }
</style>
